# Armada

Optimize bus routes (employees, bus, time) using different AI algorithms.
